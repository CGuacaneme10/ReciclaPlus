<body style="background-color: snow;">
    <div>
        <img src="assets/img/error.png" alt="">
    </div>
</body>